import os
from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_mysqldb import MySQL
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
import MySQLdb.cursors
import joblib

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# MySQL configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_PORT'] = 3306
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Kavinya#28'
app.config['MYSQL_DB'] = 'poojii'

# File Upload Configuration
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

mysql = MySQL(app)

# ---- Routes ----

# Landing Page
@app.route('/')
def landing():
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM events ORDER BY created_at DESC')
    events = cursor.fetchall()
    cursor.close()
    return render_template('landing.html', events=events) # This is the new landing page


# Admin Login
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM admin WHERE username = %s', (username,))
        admin = cursor.fetchone()
        cursor.close()

        if admin and check_password_hash(admin['password'], password):
            session['admin_id'] = admin['admin_id']
            return redirect(url_for('admin_dashboard'))

        flash('Invalid credentials!', 'danger')
    return render_template('admin_login.html')


# Admin Logout
@app.route('/admin/logout')
def admin_logout():
    session.pop('user_id', None)
    return redirect(url_for('landing'))


@app.route('/admin/dashboard')
def admin_dashboard():
    if 'admin_id' in session:
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

        # Fetch total counts
        cursor.execute('SELECT COUNT(*) AS total_users FROM users')
        total_users = cursor.fetchone()['total_users']

        cursor.execute('SELECT COUNT(*) AS total_workouts FROM workouts')
        total_workouts = cursor.fetchone()['total_workouts']

        cursor.execute('SELECT SUM(calories_burned) AS total_calories FROM workouts')
        total_calories = cursor.fetchone()['total_calories']

        # Fetch events
        cursor.execute('SELECT * FROM events')
        events = cursor.fetchall()

        cursor.close()

        # Pass everything to the template
        return render_template(
            'admin_dashboard.html', 
            total_users=total_users, 
            total_workouts=total_workouts, 
            total_calories=total_calories, 
            events=events
        )
    return redirect(url_for('admin_login'))



# Manage Users
@app.route('/admin/manage-users')
def admin_manage_users():
    if 'admin_id' in session:
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM users')
        users = cursor.fetchall()
        cursor.close()
        return render_template('admin_manage_users.html', users=users)
    return redirect(url_for('admin_login'))

# View Activities

@app.route('/admin/view-activities')
def admin_view_activities():
    if 'admin_id' in session:
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM workouts')
        workouts = cursor.fetchall()
        cursor.close()
        return render_template('admin_view_activities.html', workouts=workouts)
    return redirect(url_for('admin_login'))



# Add Event (Admin)
@app.route('/admin/add-event', methods=['GET', 'POST'])
def admin_add_event():
    if 'admin_id' in session:
        if request.method == 'POST':
            title = request.form['title']
            description = request.form['description']
            file = request.files['image']

            if file:
                filename = secure_filename(file.filename)
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)

                cursor = mysql.connection.cursor()
                cursor.execute('INSERT INTO events (title, description, image_path) VALUES (%s, %s, %s)',
                               (title, description, f'uploads/{filename}'))
                mysql.connection.commit()
                cursor.close()

                flash('Event added successfully!', 'success')
                return redirect(url_for('admin_dashboard'))
        return render_template('admin_add_event.html')
    return redirect(url_for('admin_login'))


from datetime import datetime
from flask import flash  # Import flash to send alert messages

@app.route('/workout', methods=['GET', 'POST'])
def workout():
    if 'user_id' in session:
        if request.method == 'POST':
            date = request.form['date']
            exercise = request.form['exercise']
            duration = request.form['duration']
            calories_burned = request.form['calories_burned']

            # Validate the date
            if datetime.strptime(date, '%Y-%m-%d') > datetime.now():
                flash('Workout date cannot be in the future!', 'error')  # Flash error message
                return redirect(url_for('workout'))  # Redirect back to the form

            # Insert into the database if the date is valid
            cursor = mysql.connection.cursor()
            cursor.execute('INSERT INTO workouts (user_id, date, exercise, duration, calories_burned) VALUES (%s, %s, %s, %s, %s)',
                           (session['user_id'], date, exercise, duration, calories_burned))
            mysql.connection.commit()
            cursor.close()

            flash('Workout added successfully!', 'success')  # Flash success message
            return redirect(url_for('dashboard'))
        return render_template('workout.html')
    return redirect(url_for('login'))


# Diet Tracking
@app.route('/diet', methods=['GET', 'POST'])
def diet():
    if 'user_id' in session:
        if request.method == 'POST':
            date = request.form['date']
            meal_type = request.form['meal_type']
            calories = request.form['calories']

            # Validate the date
            if datetime.strptime(date, '%Y-%m-%d') > datetime.now():
                flash('Meal date cannot be in the future!', 'error')
                return redirect(url_for('diet'))

            # Insert into the database if the date is valid
            cursor = mysql.connection.cursor()
            cursor.execute('INSERT INTO meals (user_id, date, meal_type, calories) VALUES (%s, %s, %s, %s)',
                           (session['user_id'], date, meal_type, calories))
            mysql.connection.commit()
            cursor.close()

            flash('Meal added successfully!', 'success')
            return redirect(url_for('dashboard'))
        return render_template('diet.html')
    return redirect(url_for('login'))



# Progress Tracking
@app.route('/progress', methods=['GET', 'POST'])
def progress():
    if 'user_id' in session:
        if request.method == 'POST':
            date = request.form['date']
            weight = request.form['weight']
            body_fat_percentage = request.form['body_fat_percentage']

            # Validate the date
            if datetime.strptime(date, '%Y-%m-%d') > datetime.now():
                flash('Progress date cannot be in the future!', 'error')
                return redirect(url_for('progress'))

            # Insert into the database if the date is valid
            cursor = mysql.connection.cursor()
            cursor.execute('INSERT INTO progress (user_id, date, weight, body_fat_percentage) VALUES (%s, %s, %s, %s)',
                           (session['user_id'], date, weight, body_fat_percentage))
            mysql.connection.commit()
            cursor.close()

            flash('Progress added successfully!', 'success')
            return redirect(url_for('dashboard'))
        return render_template('progress.html')
    return redirect(url_for('login'))



# User Registration
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'])
        email = request.form['email']
        age = request.form['age']
        gender = request.form['gender']

        cursor = mysql.connection.cursor()
        cursor.execute('INSERT INTO users (username, password, email, age, gender) VALUES (%s, %s, %s, %s, %s)', (username, password, email, age, gender))
        mysql.connection.commit()
        cursor.close()

        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')




# User Login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
        user = cursor.fetchone()
        cursor.close()

        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['user_id']
            return redirect(url_for('profile'))  # Corrected route for profile

        flash('Incorrect Username or Password!', 'danger')
    return render_template('login.html')


# User Profile
@app.route('/profile')
def profile():
    if 'user_id' in session:
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM users WHERE user_id = %s', (session['user_id'],))
        user = cursor.fetchone()
        cursor.close()

        if user:
            return render_template('profile.html', user=user)
        else:
            return "User not found", 404
    return redirect(url_for('login'))


# User Dashboard
@app.route('/dashboard')
def dashboard():
    if 'user_id' in session:
        user_id = session['user_id']

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM workouts WHERE user_id = %s ORDER BY date DESC', (user_id,))
        workouts = cursor.fetchall()

        cursor.execute('SELECT * FROM meals WHERE user_id = %s ORDER BY date DESC', (user_id,))
        meals = cursor.fetchall()

        cursor.execute('SELECT * FROM progress WHERE user_id = %s ORDER BY date DESC', (user_id,))
        progress_records = cursor.fetchall()

        cursor.close()
        return render_template('dashboard.html', workouts=workouts, meals=meals, progress_records=progress_records)
    return redirect(url_for('login'))



@app.route('/questions', methods=['GET', 'POST'])
def questions():
    # Safely retrieve user_id from the session
    user_id = session.get('user_id')  # Use session.get() to avoid KeyError

    if user_id is None:
        flash('Please log in to access this page.', 'warning')  # Correct usage of flash
        return redirect(url_for('login'))

    if request.method == 'POST':
        # Get user inputs
        age = int(request.form['age'])
        gender = request.form['gender']
        weight_kg = float(request.form['weight_kg'])
        height_cm = float(request.form['height_cm'])
        activity_level = request.form['activity_level']
        goal = request.form['goal']

        # Load models and encoders
        exercise_model = joblib.load(r'ml\models\exercise_model.pkl')
        diet_model = joblib.load(r'ml\models\diet_model.pkl')
        scaler = joblib.load(r'ml\models\scaler.pkl')

        gender_encoder = joblib.load(r'ml\models\gender_encoder.pkl')
        activity_level_encoder = joblib.load(r'ml\models\activity_level_encoder.pkl')
        goal_encoder = joblib.load(r'ml\models\goal_encoder.pkl')
        exercise_encoder = joblib.load(r'ml\models\recommended_exercise_encoder.pkl')  # Correct encoder path
        diet_encoder = joblib.load(r'ml\models\recommended_diet_encoder.pkl')

        # Encode inputs
        input_data = [[
            age,
            gender_encoder.transform([gender])[0],
            weight_kg,
            height_cm,
            activity_level_encoder.transform([activity_level])[0],
            goal_encoder.transform([goal])[0]
        ]]

        # Scale inputs
        input_data_scaled = scaler.transform(input_data)

        # Predict recommendations
        exercise_prediction = exercise_model.predict(input_data_scaled)[0]  # Predict class label
        diet_prediction = diet_model.predict(input_data_scaled)[0]  # Predict class label

        # Decode predictions back to original labels
        recommended_exercise = exercise_encoder.inverse_transform([exercise_prediction])[0]
        recommended_diet = diet_encoder.inverse_transform([diet_prediction])[0]

        # Save user inputs to 'questions' table
        cursor = mysql.connection.cursor()
        cursor.execute('''
            INSERT INTO questions (user_id, age, gender, weight_kg, height_cm, activity_level, goal)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        ''', (user_id, age, gender, weight_kg, height_cm, activity_level, goal))
        mysql.connection.commit()

        # Save recommendations to 'recommendations' table
        cursor.execute('''
            INSERT INTO recommendations (user_id, recommended_exercise, recommended_diet)
            VALUES (%s, %s, %s)
        ''', (user_id, recommended_exercise, recommended_diet))
        mysql.connection.commit()
        cursor.close()

        # Render recommendation
        return render_template('recommendation.html', exercise=recommended_exercise, diet=recommended_diet)

    return render_template('questions.html')


@app.route('/recommendation')
def recommendation():
    # Safely retrieve user_id from the session
    user_id = session.get('user_id')

    if user_id is None:
        flash('Please log in to access recommendations.', 'warning')
        return redirect(url_for('login'))

    # Fetch the latest recommendations from the database
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT recommended_exercise, recommended_diet FROM recommendations WHERE user_id = %s ORDER BY id DESC LIMIT 1', (user_id,))
    recommendation = cursor.fetchone()
    cursor.close()

    if recommendation:
        return render_template(
            'recommendation.html',
            exercise=recommendation['recommended_exercise'],
            diet=recommendation['recommended_diet']
        )
    else:
        flash('No recommendations found. Please complete the questionnaire first.', 'info')
        return redirect(url_for('questions'))
    


@app.route('/user/delete-workout/<int:workout_id>', methods=['POST'])
def user_delete_workout(workout_id):
    if 'user_id' in session:
        cursor = mysql.connection.cursor()
        cursor.execute('DELETE FROM workouts WHERE workout_id = %s AND user_id = %s', (workout_id, session['user_id']))
        mysql.connection.commit()
        cursor.close()
        flash('Workout deleted successfully!', 'success')
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/user/delete-progress/<int:progress_id>', methods=['POST'])
def user_delete_progress(progress_id):
    if 'user_id' in session:
        cursor = mysql.connection.cursor()
        cursor.execute('DELETE FROM progress WHERE progress_id = %s AND user_id = %s', (progress_id, session['user_id']))
        mysql.connection.commit()
        cursor.close()
        flash('Progress record deleted successfully!', 'success')
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))


@app.route('/user/delete-diet/<int:meal_id>', methods=['POST'])
def user_delete_diet(meal_id):
    if 'user_id' in session:
        cursor = mysql.connection.cursor()
        cursor.execute('DELETE FROM meals WHERE meal_id = %s AND user_id = %s', (meal_id, session['user_id']))
        mysql.connection.commit()
        cursor.close()
        flash('Meal record deleted successfully!', 'success')
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/admin/delete-user/<int:user_id>', methods=['POST'])
def admin_delete_user(user_id):
    if 'admin_id' in session:
        cursor = mysql.connection.cursor()
        cursor.execute('DELETE FROM users WHERE user_id = %s', (user_id,))
        mysql.connection.commit()
        cursor.close()
        flash('User deleted successfully!', 'success')
        return redirect(url_for('admin_manage_users'))
    return redirect(url_for('admin_login'))


@app.route('/admin/delete-event/<int:event_id>', methods=['POST'])
def admin_delete_event(event_id):
    if 'admin_id' in session:
        cursor = mysql.connection.cursor()
        cursor.execute('DELETE FROM events WHERE event_id = %s', (event_id,))
        mysql.connection.commit()
        cursor.close()
        flash('Event deleted successfully!', 'success')
        return redirect(url_for('admin_dashboard'))
    return redirect(url_for('admin_login'))




@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('landing'))


# Run the Application
if __name__ == '__main__':
    app.run(debug=True)
