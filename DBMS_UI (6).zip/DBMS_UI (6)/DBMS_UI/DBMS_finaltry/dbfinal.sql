-- Create the database
CREATE DATABASE fitness_db;
USE fitness_db;



-- Users Table
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    age INT,
    gender ENUM('Male', 'Female', 'Other')
);

-- Workouts Table
CREATE TABLE workouts (
    workout_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    date DATE NOT NULL,
    exercise VARCHAR(100) NOT NULL,
    duration INT NOT NULL,  -- in minutes
    calories_burned INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Meals Table (Diet Tracking)
CREATE TABLE meals (
    meal_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    date DATE NOT NULL,
    meal_type ENUM('Breakfast', 'Lunch', 'Dinner', 'Snack') NOT NULL,
    calories INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Progress Table
CREATE TABLE progress (
    progress_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    date DATE NOT NULL,
    weight FLOAT NOT NULL,  -- in kg
    body_fat_percentage FLOAT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Optional: Adding indexes to improve performance for commonly searched fields
CREATE INDEX idx_user_id ON workouts(user_id);
CREATE INDEX idx_user_id_meals ON meals(user_id);
CREATE INDEX idx_user_id_progress ON progress(user_id);
