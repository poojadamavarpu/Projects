
CREATE DATABASE poojii;
USE poojii;

-- Users Table
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    age INT,
    gender ENUM('Male', 'Female', 'Other')
);

-- Workouts Table
CREATE TABLE workouts (
    workout_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    date DATE NOT NULL,
    exercise VARCHAR(100) NOT NULL,
    duration INT NOT NULL,  -- in minutes
    calories_burned INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Meals Table (Diet Tracking)
CREATE TABLE meals (
    meal_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    date DATE NOT NULL,
    meal_type ENUM('Breakfast', 'Lunch', 'Dinner', 'Snack') NOT NULL,
    calories INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Progress Table
CREATE TABLE progress (
    progress_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    date DATE NOT NULL,
    weight FLOAT NOT NULL,  -- in kg
    body_fat_percentage FLOAT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE admin (
    admin_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE events (
    event_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO admin (username, password) VALUES ('admin1', 'scrypt:32768:8:1$FD2h0nry9MoEUo7d$e48382eba064100efbe0f1eac70fa81cb37db75522f2d2ca03b4675f701691e04651929c156ef138673aa90381d462f5021bd7fa83fe377e2e061a362f2d740e
');
INSERT INTO admin (username, password) VALUES ('pooja', 'scrypt:32768:8:1$nmANHItyDVNh0rNc$ee8a168af7711c77fad40941f9f30841f0fdd3b84cf6043ed00b3056f5d7d561f4a87badf3ceec8613daff6d4d328bdc1244cdc706814b478e2ae28d9bddf6f5');


select * from admin;



INSERT INTO users (username, password, email, age, gender) 
VALUES ('john_doe', 'hashed_password_1', 'john@example.com', 25, 'Male');

DELETE FROM users WHERE username = 'john_doe';


-- Insert multiple users with hashed passwords
INSERT INTO users (username, password, email, age, gender) 
VALUES 
('john_doe', 'pbkdf2:sha256:260000$randomsalt1$hashedvalue1', 'john.doe@example.com', 25, 'Male'),
('jane_doe', 'pbkdf2:sha256:260000$randomsalt2$hashedvalue2', 'jane.doe@example.com', 28, 'Female'),
('sam_smith', 'pbkdf2:sha256:260000$randomsalt3$hashedvalue3', 'sam.smith@example.com', 22, 'Other'),
('emily_clark', 'pbkdf2:sha256:260000$randomsalt4$hashedvalue4', 'emily.clark@example.com', 30, 'Female'),
('michael_brown', 'pbkdf2:sha256:260000$randomsalt5$hashedvalue5', 'michael.brown@example.com', 27, 'Male'),
('sophia_jones', 'pbkdf2:sha256:260000$randomsalt6$hashedvalue6', 'sophia.jones@example.com', 24, 'Female'),
('william_davis', 'pbkdf2:sha256:260000$randomsalt7$hashedvalue7', 'william.davis@example.com', 29, 'Male'),
('ava_martin', 'pbkdf2:sha256:260000$randomsalt8$hashedvalue8', 'ava.martin@example.com', 21, 'Female'),
('james_wilson', 'pbkdf2:sha256:260000$randomsalt9$hashedvalue9', 'james.wilson@example.com', 26, 'Male'),
('isabella_white', 'pbkdf2:sha256:260000$randomsalt10$hashedvalue10', 'isabella.white@example.com', 23, 'Female');



-- Insert sample workout data into the workouts table
INSERT INTO workouts (user_id, date, exercise, duration, calories_burned) 
VALUES 
(1, '2024-11-01', 'Running', 30, 300),
(1, '2024-11-02', 'Cycling', 45, 450),
(2, '2024-11-01', 'Yoga', 60, 200),
(2, '2024-11-03', 'Swimming', 40, 350),
(3, '2024-11-04', 'Weightlifting', 50, 400),
(3, '2024-11-05', 'Hiking', 90, 600),
(1, '2024-11-06', 'Rowing', 35, 320),
(2, '2024-11-07', 'Walking', 60, 150),
(3, '2024-11-08', 'HIIT', 30, 450),
(1, '2024-11-09', 'Dancing', 40, 280);

SELECT * FROM users;


INSERT INTO workouts (user_id, date, exercise, duration, calories_burned) 
VALUES 
(12, '2024-11-01', 'Running', 30, 300),
(12, '2024-11-02', 'Cycling', 45, 450),
(13, '2024-11-01', 'Yoga', 60, 200),
(13, '2024-11-03', 'Swimming', 40, 350),
(14, '2024-11-04', 'Weightlifting', 50, 400),
(14, '2024-11-05', 'Hiking', 90, 600),
(12, '2024-11-06', 'Rowing', 35, 320),
(13, '2024-11-07', 'Walking', 60, 150),
(14, '2024-11-08', 'HIIT', 30, 450),
(12, '2024-11-09', 'Dancing', 40, 280);


DROP TABLE IF EXISTS questions;


CREATE TABLE questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    age INT NOT NULL,
    gender VARCHAR(20) NOT NULL,
    weight_kg FLOAT NOT NULL,
    height_cm FLOAT NOT NULL,
    activity_level VARCHAR(50) NOT NULL,
    goal VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);






CREATE TABLE recommendations (
    recommendation_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    recommended_exercise VARCHAR(100) NOT NULL,
    recommended_diet VARCHAR(100) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);
DESCRIBE recommendations;
DESCRIBE users;

-- Optional: Adding indexes to improve performance for commonly searched fields
CREATE INDEX idx_user_id ON workouts(user_id);
CREATE INDEX idx_user_id_meals ON meals(user_id);
CREATE INDEX idx_user_id_progress ON progress(user_id);